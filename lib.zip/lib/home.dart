import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'past.dart';
import 'today.dart';
import 'future.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Home(),
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.grey[100],
        appBarTheme: AppBarTheme(
          elevation: 0,
          centerTitle: true,
          backgroundColor: Colors.white,
          titleTextStyle: TextStyle(
            color: Colors.blue[800],
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
          iconTheme: IconThemeData(color: Colors.blue[800]),
        ),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: Colors.blue[800],
          elevation: 4,
        ),
      ),
    );
  }
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Map<String, List<Map<String, dynamic>>> taskLists = {
    'Past': [],
    'Present': [],
    'Future': []
  };

  int _completedTasks = 0;
  int _pendingTasks = 0;

  @override
  void initState() {
    super.initState();
    _loadInitialTasks();
  }

  void _loadInitialTasks() {
    taskLists['Present']!.add({
      'task': 'Grocery Shopping',
      'date': DateTime.now().toLocal(),
      'done': false,
      'priority': 'High',
    });
    taskLists['Future']!.add({
      'task': 'Book Doctor Appointment',
      'date': DateTime.now().toLocal().add(Duration(days: 3)),
      'done': false,
      'priority': 'Medium',
    });
    taskLists['Past']!.add({
      'task': 'Pay Bills',
      'date': DateTime.now().toLocal().subtract(Duration(days: 2)),
      'done': true,
      'priority': 'High',
    });
    _calculateStats();
  }

  void _calculateStats() {
    _completedTasks = taskLists['Past']!.where((task) => task['done'] == true).length +
        taskLists['Present']!.where((task) => task['done'] == true).length;
    _pendingTasks = taskLists['Past']!.where((task) => task['done'] == false).length +
        taskLists['Present']!.where((task) => task['done'] == false).length +
        taskLists['Future']!.length;
  }

  void _refreshTasks() {
    DateTime nowSydney = DateTime.now().toLocal(); // Use local time

    List<Map<String, dynamic>> updatedPresent = [];
    List<Map<String, dynamic>> updatedPast = [];
    List<Map<String, dynamic>> updatedFuture = [];

    for (var task in taskLists['Present']!) {
      if (task['done']) {
        updatedPast.add(task);
      } else {
        updatedPresent.add(task);
      }
    }

    for (var task in taskLists['Future']!) {
      DateTime taskDateSydney = (task['date'] as DateTime).toLocal();
      if (taskDateSydney.isBefore(nowSydney.subtract(Duration(seconds: 1)))) {
        updatedPast.add(task);
      } else if (taskDateSydney.isAtSameMomentAs(nowSydney) || taskDateSydney.isBefore(nowSydney.add(Duration(seconds: 1)))) {
        updatedPresent.add(task);
      } else {
        updatedFuture.add(task);
      }
    }

    setState(() {
      taskLists['Present'] = updatedPresent;
      taskLists['Past'] = [...taskLists['Past']!, ...updatedPast];
      taskLists['Future'] = updatedFuture;
      _calculateStats();
    });
  }

  void _addTask(String task, DateTime date, String priority) {
    DateTime nowSydney = DateTime.now().toLocal();
    DateTime taskDateSydney = date.toLocal();
    String targetCategory;

    if (taskDateSydney.isBefore(nowSydney.subtract(Duration(seconds: 1)))) {
      targetCategory = 'Past';
    } else if (taskDateSydney.isAfter(nowSydney.add(Duration(seconds: 1)))) {
      targetCategory = 'Future';
    } else {
      targetCategory = 'Present';
    }

    setState(() {
      taskLists[targetCategory]?.add({
        'task': task,
        'date': date,
        'done': false,
        'priority': priority,
      });
      _calculateStats();
    });
  }

  void _updateTaskStatus(String category, int index, bool newValue) {
    setState(() {
      if (category == 'Present') {
        taskLists['Present']![index]['done'] = newValue;
        // Immediately call refreshTasks to move if done
        _refreshTasks();
      }
      _calculateStats();
    });
  }

  void _editTask(String category, int index, String newTask, DateTime newDate, String newPriority) {
    setState(() {
      taskLists[category]![index]['task'] = newTask;
      taskLists[category]![index]['date'] = newDate;
      taskLists[category]![index]['priority'] = newPriority;
      _refreshTasks(); // Refresh after editing in case the date changed significantly
      _calculateStats();
    });
  }

  void _deleteTask(String category, int index) {
    setState(() {
      taskLists[category]!.removeAt(index);
      _calculateStats();
    });
  }

  void _showEditTaskDialog(String category, int index, Map<String, dynamic> task) {
    TextEditingController taskController = TextEditingController(text: task['task']);
    DateTime selectedDate = task['date'];
    String selectedPriority = task['priority'];

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            'Edit Task',
            style: TextStyle(
              color: Colors.blue[800],
              fontWeight: FontWeight.bold,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: taskController,
                  decoration: InputDecoration(
                    hintText: 'Enter task description',
                    border: OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.grey[100],
                  ),
                  maxLines: 2,
                ),
                SizedBox(height: 16),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey[300]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: ListTile(
                    leading: Icon(Icons.calendar_today, color: Colors.blue[800]),
                    title: Text(
                      DateFormat('MMM dd, hh:mm a').format(selectedDate.toLocal()),
                      style: TextStyle(fontSize: 16),
                    ),
                    trailing: Icon(Icons.arrow_drop_down, color: Colors.blue[800]),
                    onTap: () async {
                      DateTime? picked = await showDatePicker(
                        context: context,
                        initialDate: selectedDate,
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                        builder: (context, child) {
                          return Theme(
                            data: Theme.of(context).copyWith(
                              colorScheme: ColorScheme.light(
                                primary: Colors.blue[800]!,
                                onPrimary: Colors.white,
                                onSurface: Colors.black,
                              ),
                              textButtonTheme: TextButtonThemeData(
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.blue[800],
                                ),
                              ),
                            ),
                            child: child!,
                          );
                        },
                      );
                      if (picked != null) {
                        TimeOfDay? pickedTime = await showTimePicker(
                          context: context,
                          initialTime: TimeOfDay.fromDateTime(selectedDate),
                        );
                        if (pickedTime != null) {
                          setState(() {
                            selectedDate = DateTime(
                              picked.year,
                              picked.month,
                              picked.day,
                              pickedTime.hour,
                              pickedTime.minute,
                            ).toLocal();
                          });
                        }
                      }
                    },
                  ),
                ),
                SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: selectedPriority,
                  decoration: InputDecoration(
                    labelText: 'Priority',
                    border: OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.grey[100],
                  ),
                  items: ['High', 'Medium', 'Low']
                      .map((priority) => DropdownMenuItem(
                    value: priority,
                    child: Text(priority),
                  ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedPriority = value!;
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Cancel',
                style: TextStyle(color: Colors.grey[600]),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue[800],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onPressed: () {
                if (taskController.text.isNotEmpty) {
                  _editTask(category, index, taskController.text, selectedDate, selectedPriority);
                }
                Navigator.pop(context);
              },
              child: Text(
                'Save',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildStatsCard(String title, int count, Color color) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            SizedBox(height: 8),
            Text(
              count.toString(),
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Task Dashboard'),
          bottom: TabBar(
            labelColor: Colors.blue[800],
            unselectedLabelColor: Colors.grey[600],
            indicatorColor: Colors.blue[800],
            indicatorWeight: 3,
            tabs: [
              Tab(icon: Icon(Icons.history), text: 'Past'),
              Tab(icon: Icon(Icons.today), text: 'Today'),
              Tab(icon: Icon(Icons.upcoming), text: 'Future'),
            ],
          ),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildStatsCard('Completed', _completedTasks, Colors.green),
                  _buildStatsCard('Pending', _pendingTasks, Colors.orange),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                children: [
                  PastTasks(
                    taskLists['Past']!,
                    _refreshTasks,
                    onEdit: (index, task) => _showEditTaskDialog('Past', index, task),
                    onDelete: (index) => _deleteTask('Past', index),
                  ),
                  TodayTasks( // Use TodayTasks here
                    taskLists['Present']!,
                    _refreshTasks,
                    onStatusChange: _updateTaskStatus,
                    onEdit: (index, task) => _showEditTaskDialog('Present', index, task),
                    onDelete: (index) => _deleteTask('Present', index),
                  ),
                  FutureTasks(
                    taskLists['Future']!,
                    _refreshTasks,
                    onEdit: (index, task) => _showEditTaskDialog('Future', index, task),
                    onDelete: (index) => _deleteTask('Future', index),
                  ),
                ],
              ),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: _showAddTaskDialog,
          child: Icon(Icons.add, size: 30),
          tooltip: 'Add Task',
        ),
      ),
    );
  }

  void _showAddTaskDialog() {
    TextEditingController taskController = TextEditingController();
    DateTime selectedDate = DateTime.now().toLocal();
    String selectedPriority = 'Medium';

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            'Add New Task',
            style: TextStyle(
              color: Colors.blue[800],
              fontWeight: FontWeight.bold,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: taskController,
                  decoration: InputDecoration(
                    hintText: 'Enter task description',
                    border: OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.grey[100],
                  ),
                  maxLines: 2,
                ),
                SizedBox(height: 16),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey[300]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: ListTile(
                    leading: Icon(Icons.calendar_today, color: Colors.blue[800]),
                    title: Text(
                      DateFormat('MMM dd, hh:mm a').format(selectedDate.toLocal()),
                      style: TextStyle(fontSize: 16),
                    ),
                    trailing: Icon(Icons.arrow_drop_down, color: Colors.blue[800]),
                    onTap: () async {
                      DateTime? picked = await showDatePicker(
                        context: context,
                        initialDate: selectedDate,
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                        builder: (context, child) {
                          return Theme(
                            data: Theme.of(context).copyWith(
                              colorScheme: ColorScheme.light(
                                primary: Colors.blue[800]!,
                                onPrimary: Colors.white,
                                onSurface: Colors.black,
                              ),
                              textButtonTheme: TextButtonThemeData(
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.blue[800],
                                ),
                              ),
                            ),
                            child: child!,
                          );
                        },
                      );
                      if (picked != null) {
                        TimeOfDay? pickedTime = await showTimePicker(
                          context: context,
                          initialTime: TimeOfDay.fromDateTime(selectedDate),
                        );
                        if (pickedTime != null) {
                          setState(() {
                            selectedDate = DateTime(
                              picked.year,
                              picked.month,
                              picked.day,
                              pickedTime.hour,
                              pickedTime.minute,
                            ).toLocal();
                          });
                        }
                      }
                    },
                  ),
                ),
                SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: selectedPriority,
                  decoration: InputDecoration(
                    labelText: 'Priority',
                    border: OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.grey[100],
                  ),
                  items: ['High', 'Medium', 'Low']
                      .map((priority) => DropdownMenuItem(
                    value: priority,
                    child: Text(priority),
                  ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedPriority = value!;
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Cancel',
                style: TextStyle(color: Colors.grey[600]),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue[800],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onPressed: () {
                if (taskController.text.isNotEmpty) {
                  _addTask(taskController.text, selectedDate, selectedPriority);
                }
                Navigator.pop(context);
              },
              child: Text(
                'Add Task',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        );
      },
    );
  }
}
