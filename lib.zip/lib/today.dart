import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TodayTasks extends StatefulWidget {
  final List<Map<String, dynamic>> todayTasks;
  final VoidCallback refreshTasks;
  final Function(String, int, bool) onStatusChange;
  final Function(int, Map<String, dynamic>) onEdit;
  final Function(int) onDelete;

  TodayTasks(
      this.todayTasks,
      this.refreshTasks, {
        required this.onStatusChange,
        required this.onEdit,
        required this.onDelete,
      });

  @override
  _TodayTasksState createState() => _TodayTasksState();
}

class _TodayTasksState extends State<TodayTasks> {
  @override
  Widget build(BuildContext context) {
    if (widget.todayTasks.isEmpty) {
      return Center(
        child: Text('No tasks for today.'),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: widget.todayTasks.length,
      itemBuilder: (context, index) {
        final task = widget.todayTasks[index];
        return Card(
          margin: EdgeInsets.symmetric(vertical: 8.0),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Checkbox(
                  value: task['done'],
                  onChanged: (newValue) {
                    widget.onStatusChange('Present', index, newValue!);
                  },
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        task['task'],
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          decoration: task['done'] ? TextDecoration.lineThrough : null,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        DateFormat('MMM dd, hh:mm a').format(task['date'].toLocal()),
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Priority: ${task['priority']}',
                        style: TextStyle(fontStyle: FontStyle.italic),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.edit, color: Colors.blue[800]),
                  onPressed: () => widget.onEdit(index, task),
                ),
                IconButton(
                  icon: Icon(Icons.delete, color: Colors.red[600]),
                  onPressed: () => widget.onDelete(index),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}